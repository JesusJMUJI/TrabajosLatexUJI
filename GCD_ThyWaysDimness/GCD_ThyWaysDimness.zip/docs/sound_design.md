1. Explain in general, what kind of sound ambient  do you want to give to your game.

2. Describe the musical characteristics of your videogame soundtrack: musical references, type of rhythm, kind of environment. Is there more of a soundtrack?

3. Are there one or more sound ambients in your game?

Describe it together and the type of sounds that comprise it.

4. Describe the different sounds that you use to give sound to the interactions and mechanics that occur in the game.

Develop a table describing in detail the following characteristics of your game:

- Type of music used: mood, beat and accent in special situations.

- Environmental effects.

- All sounds corresponding to all mechanics used
